//
//  Task.m
//  ToDo List
//
//  Created by Davey McNight on 6/23/15.
//  Copyright (c) 2015 msse650. All rights reserved.
//

#import "Task.h"
#import "Subtask.h"


@implementation Task

@dynamic name;
@dynamic tasks;




@end
