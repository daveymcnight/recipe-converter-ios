//
//  Subtask.m
//  ToDo List
//
//  Created by Davey McNight on 6/23/15.
//  Copyright (c) 2015 msse650. All rights reserved.
//

#import "Subtask.h"
#import "Task.h"


@implementation Subtask

@dynamic name;
@dynamic task;

@end
