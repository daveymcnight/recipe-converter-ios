//
//  Contact.m
//  ToDo List
//
//  Created by Davey McNight on 6/23/15.
//  Copyright (c) 2015 msse650. All rights reserved.
//

#import "Contact.h"



@implementation Contact

@dynamic name;
@dynamic contacts;




@end
